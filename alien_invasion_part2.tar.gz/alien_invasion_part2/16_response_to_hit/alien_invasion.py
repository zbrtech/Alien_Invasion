import sys
import pygame
from settings import Settings
from ship import Ship
from alien import Alien
import game_functions as gf
from game_stats import GameStats
from pygame.sprite import Group   #用这个类来包括所有发出去的子弹，功能类似于列表

def run_game():
	#初始化游戏，并创建一块显示屏幕
	pygame.init()
	ai_settings = Settings()
	screen = pygame.display.set_mode((ai_settings.screen_width, ai_settings.screen_height))
	pygame.display.set_caption("Alien_Invasion")

	stats = GameStats(ai_settings)

	ship = Ship(ai_settings, screen)        #a ship

	## alien = Alien(ai_settings, screen)
	aliens = Group()                        #a empty aliens group
	gf.create_fleet(ai_settings, screen, ship, aliens)    #create the aliens group

	bullets = Group()  #这个存子弹用的Group类要定义在主循环之外，否则每次循环都创建一个，会很卡
			#到时候作为参数传进去功能函数里面，以Group的形式去add装载之前定义好的bullets类的实例
						#a empty bullets group

	#开始主程序循环
	while True:
        
	
		'''for event in pygame.event.get():
			if event.type == pygame.QUIT:
			sys.exit()'''
		gf.check_events(ai_settings, screen, ship, bullets)  
				#调用封装在外面模块的函数，替代上面的代码,更简洁,检查用户是否按关闭按钮
				#这边就要传递参数进去啦，因为要操作ship。前几章不用操作，所以不用传

		ship.update()   #检测标志位来决定飞机的移动
		gf.update_bullets(ai_settings, screen, ship, aliens, bullets)
		
		gf.update_aliens(ai_settings, stats, screen, ship, aliens, bullets)

		'''screen.fill(ai_settings.bg_color)  #给屏幕填充颜色
		ship.blitme()  #ship模块中定义的函数，用于把飞船图显示出来
		#显示最后刷新的页面
		pygame.display.flip()'''
		gf.update_screen(ai_settings, screen, ship, aliens, bullets)

run_game()
