import pygame

class Ship():

	def __init__(self, ai_settings, screen):
		self.screen = screen
		self.ai_settings = ai_settings

		self.image = pygame.image.load('images/ship.bmp')  #load ship image
		self.rect = self.image.get_rect()
		self.screen_rect = screen.get_rect()   #get the rect of the ship image

		self.rect.centerx = self.screen_rect.centerx
		self.rect.bottom = self.screen_rect.bottom

		self.moving_right = False  #该属性（当一个标志使用）为False的时候，飞船不动;True才动，不断检查该属性
		self.moving_left = False

		self.center = float(self.rect.centerx)  #强制转化为小数，并存入self.center属性，后续改用该属性。小数比较适用。

	def update(self):   #不断扫描ship的moving_right属性是否变成True，变了才执行后面的操作
		if (self.moving_right == True) and (self.rect.right < self.screen_rect.right):
			self.center += self.ai_settings.ship_speed_factor
		if (self.moving_left == True) and (self.rect.left > 0):
			self.center -= self.ai_settings.ship_speed_factor

		self.rect.centerx = self.center  #最后还是要换回来

	def blitme(self):
		self.screen.blit(self.image, self.rect)   #show ship

	def center_ship(self):
		self.center = self.screen_rect.centerx
