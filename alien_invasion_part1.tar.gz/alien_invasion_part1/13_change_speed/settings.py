# file 3

class Settings():
#store all settings of this game

	def __init__(self):  # init all settings of this game

		#set screen
		self.screen_width = 900
		self.screen_height = 600
		self.bg_color = (230,230,230)

		self.ship_speed_factor = 1.5


