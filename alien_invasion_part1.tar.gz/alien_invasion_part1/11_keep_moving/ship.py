import pygame

class Ship():

	def __init__(self, screen):
		self.screen = screen

		self.image = pygame.image.load('images/ship.bmp')  #load ship image
		self.rect = self.image.get_rect()
		self.screen_rect = screen.get_rect()   #get the rect of the ship image

		self.rect.centerx = self.screen_rect.centerx
		self.rect.bottom = self.screen_rect.bottom

		self.moving_right = False  #该属性（当一个标志使用）为False的时候，飞船不动;True才动，不断检查该属性

	def update(self):   #不断扫描ship的moving_right属性是否变成True，变了才执行后面的操作
		if self.moving_right == True:
			self.rect.centerx += 1

	def blitme(self):
		self.screen.blit(self.image, self.rect)   #show ship
