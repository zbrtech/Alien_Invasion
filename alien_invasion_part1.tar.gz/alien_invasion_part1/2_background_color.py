import sys

import pygame

def run_game():
    #init game, and create a screen object
    pygame.init()
    screen = pygame.display.set_mode((600,400))
    pygame.display.set_caption("Alien Invasion")

    bg_color = (230,230,230)  # set one color 

    #start the main circle of game
    while True:
        #watch keyboard event and mouseclick event
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

        screen.fill(bg_color)  #everytime fill color for secreen 

        #show the latest drawed display
        pygame.display.flip()

run_game()
